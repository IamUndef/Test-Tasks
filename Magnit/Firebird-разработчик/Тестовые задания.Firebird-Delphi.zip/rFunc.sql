/*====================================================================
                File rfunc6.sql

                rFunc InterBase UDF library.
                Install SQL-script for IB 6.x.

                Copyright 1998-2003 Polaris Software
                http://rfunc.sourceforge.net
                mailto:rFunc@mail.ru

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.
    See license.txt for more details.

====================================================================== */

/* Define valid path and password for your database */
/* 6.x Windows local Firebird Dialect 1 */
/*CONNECT 'c:\progra~1\firebird\examples\v5\employee.gdb' USER 'SYSDBA' PASSWORD 'masterkey';*/
/* 6.x Windows local Borland Dialect 1 */
/*CONNECT 'c:\progra~1\borland\interbase\examples\database\employee.gdb' USER 'SYSDBA' PASSWORD 'masterkey';*/
/* 6.x Windows local Dialect 3 */
/*CONNECT 'c:\ib6\test\test6.gdb' USER 'SYSDBA' PASSWORD 'masterkey';*/
/* 6.x Linux remote Dialect 1 */
/*CONNECT 'iblinux:/opt/interbase/examples/employee.gdb' USER 'SYSDBA' PASSWORD 'masterkey';*/
/* 6.x Linux remote Dialect 3 */
/*CONNECT 'mlinux:/base/test6.gdb' USER 'SYSDBA' PASSWORD 'masterkey';*/

/* functions */

DECLARE EXTERNAL FUNCTION STRPOS
   CSTRING(16383), CSTRING(16383)
   RETURNS INTEGER BY VALUE
  ENTRY_POINT 'fn_strpos'  MODULE_NAME 'rfunc';

DECLARE EXTERNAL FUNCTION STRLEN
   CSTRING(16383)
   RETURNS INTEGER BY VALUE
  ENTRY_POINT 'fn_strlen'  MODULE_NAME 'rfunc';

DECLARE EXTERNAL FUNCTION SUBSTR
   CSTRING(255), INTEGER, INTEGER
   RETURNS CSTRING(255)
  ENTRY_POINT 'fn_substr'  MODULE_NAME 'rfunc';
  
DECLARE EXTERNAL FUNCTION STRREPLACE
   CSTRING(255), CSTRING(255), CSTRING(255)
   RETURNS CSTRING(255) FREE_IT
  ENTRY_POINT 'fn_strreplace'  MODULE_NAME 'rfunc';

DECLARE EXTERNAL FUNCTION ORD
   CSTRING(1)
   RETURNS SMALLINT BY VALUE
  ENTRY_POINT 'fn_ord'  MODULE_NAME 'rfunc';
  
DECLARE EXTERNAL FUNCTION FLOATTOSTR
   DOUBLE PRECISION, CSTRING(255)
   RETURNS CSTRING(255) FREE_IT
  ENTRY_POINT 'fn_floattostr'  MODULE_NAME 'rfunc';

