create or alter procedure R_XMLCONVERTSTRING (
    ASTR varchar(255),
    FLAGS varchar(10))
returns (
    TEXT varchar(255))
AS
declare variable I integer;
declare variable P integer;
declare variable SYMBOL varchar(1);
declare variable HEXCODE varchar(2);
declare variable FULLHEXCODE varchar(2);
declare variable DECCODE integer;
declare variable HEXPREFIX varchar(3);
declare variable HEXTABLE varchar(16);
declare variable WHILE1 integer;
declare variable TEXTLENGTH integer;
declare variable TEXTSYMBOL varchar(8);
declare variable BUFFTEXT varchar(255);
BEGIN
  /* FLAGS:
      T - �� xml � �����
      X - �� ������ � xml (�� ���������)
        e  - ��������������� ���������� ��������
  */
  IF (FLAGS IS NULL) THEN FLAGS = 'X';
  IF (STRLEN(ASTR) > 0) THEN
    IF (SubStr(FLAGS, 1, 1) = 'T') THEN BEGIN
      TEXT = STRREPLACE(ASTR, '&amp;', '&');
      TEXT = STRREPLACE(TEXT, '&gt;', '>');
      TEXT = STRREPLACE(TEXT, '&lt;', '<');
      TEXT = STRREPLACE(TEXT, '&quot;', '"');
      TEXT = STRREPLACE(TEXT, '&apos;', '''');

      /* &#xXX Symbols */
      HEXTABLE = '0123456789ABCDEF';
      HEXREFIX = '&#x';
      P = STRPOS(HEXREFIX, TEXT);
      WHILE (P > 1) DO BEGIN
        I = P + 3;
        SYMBOL = SUBSTR(TEXT, I, 1);
        HEXCODE = '';
        WHILE (SYMBOL != ';') DO BEGIN
          HEXCODE = HEXCODE||SYMBOL;
          I = I + 1;
          SYMBOL = SUBSTR(TEXT, I, 1);
        END
        IF (STRLEN(HEXCODE) = 1) THEN FULLHEXCODE = '0'||HEXCODE;
        ELSE FULLHEXCODE = HEXCODE;
        DECCODE = 16 * (STRPOS(SUBSTR(FULLHEXCODE, 1, 1), HEXTABLE) - 1) + (STRPOS(SUBSTR(FULLHEXCODE, 2, 1), HEXTABLE) - 1);
        TEXT = STRREPLACE(TEXT, HEXPREFIX||HEXCODE||';', CHR(DECCODE));
        P = STRPOS(HEXPREFIX, TEXT);
      END
    END
    ELSE IF (SubStr(FLAGS, 1, 1) = 'X') THEN BEGIN
      TEXT = STRREPLACE(ASTR, '&', '&amp;');
      TEXT = STRREPLACE(TEXT, '>', '&gt;');
      TEXT = STRREPLACE(TEXT, '>', '&lt;');
      TEXT = STRREPLACE(TEXT, '"', '&quot;');
      TEXT = STRREPLACE(TEXT, '''', '&apos;');
      if (strpos('e', :flags) <> 0) then begin
        while1 = 1;
        textlength = strlen(:text);
        bufftext = '';
        while (:while1 <= :textlength) do begin
          textsymbol = substr(:text, :while1, 1);
          if (ord(:textsymbol) <= 31) then bufftext = :bufftext || '&#x' || floattostr(ord(:textsymbol), '%X') || ';';
            else bufftext = :bufftext || :textsymbol;
         while1 = :while1 + 1;
        end
        text = :bufftext;
    END
END

